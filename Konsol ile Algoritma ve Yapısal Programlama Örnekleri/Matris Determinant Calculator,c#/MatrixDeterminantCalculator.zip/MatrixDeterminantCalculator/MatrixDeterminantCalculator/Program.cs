﻿
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter the size of the matrix:");
        int matrixSize = GetInputNumber();
        int[,] matrix = new int[matrixSize, matrixSize];

        Console.WriteLine("Enter the elements of the matrix:");
        for (int i = 0; i < matrixSize; i++)
        {
            for (int j = 0; j < matrixSize; j++)
            {
                matrix[i, j] = GetInputNumber();
            }
        }

        int determinant = CalculateDeterminant(matrix, matrixSize);
        Console.WriteLine("The determinant of the matrix is: {0}", determinant);
    }

    static int CalculateDeterminant(int[,] matrix, int matrixSize)
    {
        if (matrixSize == 1)
        {
            return matrix[0, 0];
        }
        else if (matrixSize == 2)
        {
            return matrix[0, 0] * matrix[1, 1] - matrix[0, 1] * matrix[1, 0];
        }
        else
        {
            int determinant = 0;
            for (int i = 0; i < matrixSize; i++)
            {
                int[,] subMatrix = GetSubMatrix(matrix, matrixSize, i);
                int subMatrixDeterminant = CalculateDeterminant(subMatrix, matrixSize - 1);
                determinant += ((i % 2 == 0) ? 1 : -1) * matrix[0, i] * subMatrixDeterminant;
            }
            return determinant;
        }
    }

    static int[,] GetSubMatrix(int[,] matrix, int matrixSize, int columnToRemove)
    {
        int[,] subMatrix = new int[matrixSize - 1, matrixSize - 1];
        for (int i = 1; i < matrixSize; i++)
        {
            for (int j = 0; j < matrixSize; j++)
            {
                if (j < columnToRemove)
                {
                    subMatrix[i - 1, j] = matrix[i, j];
                }
                else if (j > columnToRemove)
                {
                    subMatrix[i - 1, j - 1] = matrix[i, j];
                }
            }
        }
        return subMatrix;
    }

    static int GetInputNumber()
    {
        int inputNumber;
        while (!int.TryParse(Console.ReadLine(), out inputNumber))
        {
            Console.WriteLine("Invalid input. Please enter a number.");
        }
        return inputNumber;
    }
}
