﻿Console.WriteLine("Taş kağıt makas oyununa hoş geldiniz!");

string[] choices = new string[] { "Taş", "Kağıt", "Makas" };
Random random = new Random();

while (true)
{
    Console.WriteLine("\nSeçiminizi yapın: (1) Taş, (2) Kağıt, (3) Makas");
    int userChoice = int.Parse(Console.ReadLine()) - 1;
    Console.WriteLine("Sizin seçiminiz: " + choices[userChoice]);

    int computerChoice = random.Next(0, 3);
    Console.WriteLine("Bilgisayarın seçimi: " + choices[computerChoice]);

    if (userChoice == computerChoice)
    {
        Console.WriteLine("Berabere!");
    }
    else if ((userChoice == 0 && computerChoice == 2) ||
             (userChoice == 1 && computerChoice == 0) ||
             (userChoice == 2 && computerChoice == 1))
    {
        Console.WriteLine("Kazandınız!");
    }
    else
    {
        Console.WriteLine("Kaybettiniz!");
    }

    Console.WriteLine("Devam etmek istiyor musunuz? (E/H)");
    string answer = Console.ReadLine();
    if (answer.ToLower() != "e")
    {
        break;
    }
}

Console.WriteLine("Oyundan çıkılıyor. İyi günler!");