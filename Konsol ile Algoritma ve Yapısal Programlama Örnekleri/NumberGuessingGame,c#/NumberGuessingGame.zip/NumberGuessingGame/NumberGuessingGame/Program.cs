﻿
Console.WriteLine("Sayı tahmin oyununa hoş geldiniz!"); 
        Console.WriteLine("Lütfen aşağıdaki zorluk seviyelerinden birisini seçiniz:");
        Console.WriteLine("1. Kolay seviye için 1'i tuşlayın");
        Console.WriteLine("2. Orta seviye için 2'i tuşlayın");
        Console.WriteLine("3. Zor seviye için 3'ü tuşlayın");

int difficultyLevel = 0;
bool validInput = false;

while (!validInput)
{
    Console.Write("Zorluk seviyesi: ");
    string input = Console.ReadLine();

    if (int.TryParse(input, out difficultyLevel))
    {
        if (difficultyLevel >= 1 && difficultyLevel <= 3)
        {
            validInput = true;
        }
        else
        {
            Console.WriteLine("Yanlış bir giriş yaptınız! Lütfen geçerli bir zorluk seviyesi seçiniz.");
        }
    }
    else
    {
        Console.WriteLine("Geçerli bir sayı girişi yapmadınız! Lütfen tekrar deneyin.");
    }
}

int minNumber, maxNumber;

if (difficultyLevel == 1)
{
    minNumber = 1;
    maxNumber = 10;
}
else if (difficultyLevel == 2)
{
    minNumber = 1;
    maxNumber = 100;
}
else
{
    minNumber = 1;
    maxNumber = 1000;
}

Random randomNumber = new Random();
int targetNumber = randomNumber.Next(minNumber, maxNumber + 1);
//

Console.WriteLine("Oyun başlıyor!");
Console.WriteLine($"Tahmin edilecek sayı {minNumber} ile {maxNumber} arasında bir sayıdır.");

int guessCount = 0;
bool correctGuess = false;

while (!correctGuess)
{
    Console.Write("Tahmininizi yazınız: ");
    int guess;
    if (int.TryParse(Console.ReadLine(), out guess))
    {
        guessCount++;

        if (guess == targetNumber)
        {
            correctGuess = true;
            Console.WriteLine($"Tebrikler!! {guess} doğru tahmin!");
            Console.WriteLine($"Oyunu {guessCount} tahminde bitirdiniz.");
        }
        else if (guess < targetNumber)
        {
            Console.WriteLine("Daha büyük bir sayı girin.");
        }
        else
        {
            Console.WriteLine("Daha küçük bir sayı girin.");
        }
    }
    else
    {
        Console.WriteLine("Geçersiz bir sayı girdiniz. Tekrar deneyin.");
    }
}



Console.WriteLine();

        Console.Write("Oyunu tekrar oynamak istiyor musunuz? (E/H): ");
        string playAgainInput = Console.ReadLine();
        if (playAgainInput.ToLower() == "e" || playAgainInput.ToLower() == "E")
        {
            Console.WriteLine();
          return; // Oyunu tekrar başlat
        }
        else
        {
            Console.WriteLine("Oyun bitti. Çıkış yapılıyor.");
        }
 